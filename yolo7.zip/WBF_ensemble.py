import os, csv
import pandas as pd
from ensemble_boxes import *
from tqdm import tqdm

result_folders = [
    "./runs/test/yolo_val_IR_pre/labels_csv",
    "./runs/test/yolo7_val_IR/labels_csv"
]

save_dir = './ensemble_labels'
os.makedirs(save_dir, exist_ok=True)

#########################
iou_thr = 0.4 
skip_box_thr = 0.0001
sigma = 0.1
#########################

file_names = os.listdir(result_folders[0])
for file in tqdm(file_names):
    label_lists = [[]]*len(result_folders)
    score_lists = [[]]*len(result_folders)
    box_lists = [[]]*len(result_folders)

    for i, folder in enumerate(result_folders):
        try:
            df = pd.read_csv(os.path.join(folder, file), header = None, encoding='UTF-8')
            for row in df.iterrows():
                id, score, x1, y1, x2, y2 = row[1]
                bbox = [x1, y1, x2, y2]
                label_lists[i].append(id)
                score_lists[i].append(score)
                box_lists[i].append(bbox)
        except:
            pass

    boxes, scores, labels = weighted_boxes_fusion(box_lists, score_lists, label_lists, iou_thr=iou_thr, skip_box_thr=skip_box_thr)

    csv_file = open(os.path.join(save_dir, file), 'w', newline='', encoding='UTF-8')
    csv_writer = csv.writer(csv_file)
    for i in range(len(boxes)):
        csv_writer.writerow([labels[i], scores[i], *boxes[i]])
    csv_file.close()








