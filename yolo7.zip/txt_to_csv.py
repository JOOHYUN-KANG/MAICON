import os, csv
import numpy as np
import pandas as pd
from tqdm import tqdm

txt_file_path = './runs/test/yolo_val_IR_pre/labels'
save_csv_path = './runs/test/yolo_val_IR_pre/labels_csv'
os.makedirs(save_csv_path, exist_ok=True)

txt_files = os.listdir(txt_file_path)

for txt_file in tqdm(txt_files):

    with open(os.path.join(txt_file_path, txt_file), 'r') as f:
        lines = f.readlines()

    file_name = txt_file.replace('.txt', '.csv')
    csv_file = open(os.path.join(save_csv_path, file_name), 'w', newline='', encoding='UTF-8')
    csv_writer = csv.writer(csv_file)
    for line in lines:
        line = line.strip().split(' ')
        id, x_c, y_c, w, h, score = list(map(float, line))
        x1, y1, x2, y2 = max(0, (x_c - w/2)), max(0, (y_c- h/2)), min(1, (x_c + w/h)), min(1,(y_c + h/2))
        csv_writer.writerow([id, score, x1, y1, x2, y2])
    csv_file.close()