import os, csv
import numpy as np
import pandas as pd
from tqdm import tqdm

csv_file_path = './ensemble_labels'
save_csv_path = './evaluate'
os.makedirs(save_csv_path, exist_ok=True)

csv_files = os.listdir(csv_file_path)

new_csv_file = open(os.path.join(save_csv_path, 'ensemble.csv'), 'w', newline='', encoding='UTF-8')
csv_writer = csv.writer(new_csv_file)
csv_writer.writerow(['ImageID','LabelName','Conf','XMin','XMax','YMin','YMax'])
# csv_writer.writerow(['ImageID','LabelName','XMin','XMax','YMin','YMax'])

for csv_file in tqdm(csv_files):

    with open(os.path.join(csv_file_path, csv_file), 'r') as f:
        lines = f.readlines()

    file_name = csv_file.replace('.csv', '.jpg')

    for line in lines:
        line = line.strip().split(',')
        id, score, x1, y1, x2, y2  = list(map(float, line))
        csv_writer.writerow([file_name, id, score, x1, x2, y1, y2])


new_csv_file.close()