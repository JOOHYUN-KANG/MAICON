import os, shutil

file_dir = os.path.dirname('C:/yolov7-main/hub_data/test/images/')
print(file_dir)
file_cnt = 0
for path, dirs, files in os.walk(file_dir):
    for file in files:
        
        file_cnt += 1
        file_path = os.path.join(path, file)
        txt_path = os.path.join(path.replace('images', 'labels'), file.replace('.jpg', '.txt'))

        if file.startswith('IR'):
            dest_path = 'C:/yolov7-main/hub_data/test/images/IR/' + file
            txt_dest = 'C:/yolov7-main/hub_data/test/labels/IR/' + file.replace('.jpg', '.txt')
            
        elif file.startswith('TH'):
            dest_path = 'C:/yolov7-main/hub_data/test/images/TH/' + file
            txt_dest = 'C:/yolov7-main/hub_data/test/labels/TH/' + file.replace('.jpg', '.txt')

        try:
            shutil.move(txt_path, txt_dest)
            shutil.move(file_path, dest_path)
        except:
            pass
        
    print('현재까지 완료된 file 수:', file_cnt)