import json, csv, os

def voc_to_coco(x1, y1, x2, y2):
    x = x1
    y = y1
    width = x2 - x1
    height = y2 - y1
    return x, y, width, height
 
json_file_path = './sample_data/json'
json_lists = os.listdir(json_file_path)
save_txt_path = './sample_data/txt'

os.makedirs(save_txt_path, exist_ok=True)

for json_file in json_lists:

    with open(os.path.join(json_file_path, json_file), encoding='UTF-8') as f:
        data = json.load(f)
    
    width = data['image']['size']['width']
    height = data['image']['size']['height']
    labels = []
    for label in data['annotation']:
        id = label['property']['category_id']
        box = label['bndbox']
        labels.append((data['image']['file_name'][9:], id, box))

    file_name = os.path.basename(json_file).replace('.json', '.txt')
    txt_file = open(os.path.join(save_txt_path, file_name), 'w', newline='', encoding='UTF-8')

    for label in labels:
        id, x1, y1, x2, y2 = label[1], *label[2].values()
        x, y, w, h = voc_to_coco(x1, y1, x2, y2)
        txt_file.write(f'{id} {x/width} {y/height} {w/width} {h/height}\n')
    f.close()
