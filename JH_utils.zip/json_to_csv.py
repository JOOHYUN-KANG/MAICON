import json, csv, os
 
json_file_path = './sample_data/json'
json_lists = os.listdir(json_file_path)
save_csv_path = './sample_data/csv'

os.makedirs(save_csv_path, exist_ok=True)

for json_file in json_lists:

    with open(os.path.join(json_file_path, json_file), encoding='UTF-8') as f:
        data = json.load(f)
    

    labels = []
    for label in data['annotation']:
        id = label['property']['category_id']
        box = label['bndbox']
        labels.append((data['image']['file_name'][9:], id, box))

    file_name = os.path.basename(json_file).replace('.json', '.csv')
    csv_file = open(os.path.join(save_csv_path, file_name), 'w', newline='', encoding='UTF-8')
    csv_writer = csv.writer(csv_file)
    
    # Counter variable used for writing
    # headers to the CSV file
    count = 0
    for label in labels:
        if count == 0:
            header = ['file_name','id','x1','y1','x2','y2']
            csv_writer.writerow(header)
            count += 1

        csv_writer.writerow([label[0], label[1], label[2]['xmin'], label[2]['ymin'], label[2]['xmax'], label[2]['ymax']])
    csv_file.close()