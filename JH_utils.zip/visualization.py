import cv2, os, random
import matplotlib.pyplot as plt
import pandas as pd

raw_img_dir = './sample_data/image'
label_dir = './sample_data/csv'
save_img_dir = './sample_data/image_with_box'
os.makedirs(save_img_dir, exist_ok=True)


def plot_one_box(box, image, color=None, label=None, line_thickness=None):
    tl = line_thickness or round(0.002 * (image.shape[0] + image.shape[1]) / 2) + 1  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(box[0]), int(box[1])), (int(box[2]), int(box[3]))
    cv2.rectangle(image, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA) # draw box(rectangle) on image

    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(image, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(image, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)


def yolo_to_voc(x_center, y_center, width, height):
    x1 = round(x_center - width / 2)
    y1 = round(y_center - height / 2)
    x2 = round(x_center + width / 2)
    y2 = round(y_center + height / 2)  
    return x1, y1, x2, y2



def draw_box_on_image(file_name, classes, colors, raw_img_dir, label_dir, save_img_dir, type:str):
    
    img_path = os.path.join(raw_img_dir, f'{file_name}.jpg')
    label_path  = os.path.join(label_dir, f'{file_name}.csv')
    save_file_path = os.path.join(save_img_dir, f'{file_name}_with_box.jpg')
    
    img = cv2.imread(img_path)
    # label_df = pd.read_csv(label_path, names=['file_name','id','x1','y1','x2','y2'])
    label_df = pd.read_csv(label_path)

    try:
        height, width, channels = img.shape
    except:
        print('no shape info.')
        return 0

    box_number = 0

    for idx, row in label_df.iterrows():
        class_idx = row[1]

        if type == 'yolo':  
            x_center, y_center, w, h =row[2:]
            x1, y1, x2, y2 = yolo_to_voc(x_center, y_center, w, h)
        elif type == 'voc':
            x1, y1, x2, y2 = row[2:]
        plot_one_box([x1,y1,x2,y2], img, color=colors[class_idx], label=classes[class_idx], line_thickness=None)

        cv2.imwrite(save_file_path, img)

        box_number += 1
    return box_number


if __name__ == '__main__':

    random.seed(42)
    classes = ['1_Human', '2_Human with Motocycle', '3_Human with Bicycle', '4_Human with Kickboard']
    colors = [[random.randint(0, 255) for _ in range(3)] for _ in range(len(classes))]
    file_names = [os.path.basename(x).replace('.jpg', '') for x in os.listdir(raw_img_dir)]

    box_total = 0
    image_total = 0
    for file_name in file_names: 
        box_num = draw_box_on_image(file_name, classes, colors, raw_img_dir, label_dir, save_img_dir, type='voc')
        box_total += box_num
        image_total += 1
        print('Box number:', box_total, 'Image number:',image_total)